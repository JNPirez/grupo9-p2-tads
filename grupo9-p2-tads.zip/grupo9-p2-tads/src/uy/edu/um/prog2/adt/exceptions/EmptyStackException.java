package uy.edu.um.prog2.adt.exceptions;

public class EmptyStackException extends Exception{
}
