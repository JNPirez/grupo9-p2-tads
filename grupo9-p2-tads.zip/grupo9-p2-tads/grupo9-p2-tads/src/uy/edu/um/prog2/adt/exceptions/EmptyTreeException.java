package uy.edu.um.prog2.adt.exceptions;

public class EmptyTreeException extends Exception {
}
